package ordina.youbionic.Exception;

public class IllegalEnumValueException extends Exception{
    public IllegalEnumValueException(String errorMessage){
        super(errorMessage);
    }
}
