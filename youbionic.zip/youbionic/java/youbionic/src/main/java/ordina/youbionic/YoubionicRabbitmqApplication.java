package ordina.youbionic;

import ordina.youbionic.infrastructure.QueueEnum;
import ordina.youbionic.infrastructure.RabbitMQPublisher;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class YoubionicRabbitmqApplication {

	public static void main(String[] args) {
		SpringApplication.run(YoubionicRabbitmqApplication.class, args);
	}

	@GetMapping("/test0")
	public String test0() throws Exception{
		RabbitMQPublisher publisher = new RabbitMQPublisher();
		publisher.publish(QueueEnum.SERVO, "15,0");
		return "Great succes";
	}

	@GetMapping("/test1")
	public String test1() throws Exception{
		RabbitMQPublisher publisher = new RabbitMQPublisher();
		publisher.publish(QueueEnum.SERVO, "15,180");
		return "Great succes";
	}
}
