package ordina.youbionic.infrastructure;

public enum QueueEnum {
    SERVO,
    AUDIO_INPUT,
    AUDIO_OUTPUT
}
